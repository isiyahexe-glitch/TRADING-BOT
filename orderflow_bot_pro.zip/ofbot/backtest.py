"""Candle-based backtester (uses candle delta proxy, so results are indicative only)."""
import numpy as np
import pandas as pd

import strategy as strat
from config import Settings


def run_backtest(df_raw: pd.DataFrame, s: Settings, warmup: int = 120, step: int = 1) -> dict:
    trades = []
    i = warmup
    n = len(df_raw)
    while i < n - 2:
        window = df_raw.iloc[: i + 1].reset_index(drop=True)
        a = strat.analyse(window, None, s)
        sig = strat.evaluate(a, s)
        if sig.side == "WAIT":
            i += step
            continue
        sg = 1 if sig.side == "BUY" else -1
        entry = float(df_raw["close"].iloc[i])
        sl = entry - sg * s.sl_pips * s.pip_size
        tp1 = entry + sg * s.tp1_pips * s.pip_size
        tp2 = entry + sg * s.tp2_pips * s.pip_size
        half_r1 = s.tp1_pips / s.sl_pips
        half_r2 = s.tp2_pips / s.sl_pips
        tp1_hit, result, j = False, None, i + 1
        cur_sl = sl
        while j < n:
            hi, lo = df_raw["high"].iloc[j], df_raw["low"].iloc[j]
            hit_sl = lo <= cur_sl if sg > 0 else hi >= cur_sl
            hit_tp1 = hi >= tp1 if sg > 0 else lo <= tp1
            hit_tp2 = hi >= tp2 if sg > 0 else lo <= tp2
            if hit_sl:                       # pessimistic: SL first inside a candle
                r = -1.0 if not tp1_hit else 0.0
                result = (half_r1 * 0.5 + 0.5 * 0.0) if tp1_hit else r
                break
            if not tp1_hit and hit_tp1:
                tp1_hit = True
                if s.move_be_after_tp1:
                    cur_sl = entry
            if hit_tp2:
                result = 0.5 * half_r1 + 0.5 * half_r2
                break
            j += 1
        if result is None:                   # still open at end of data
            result = 0.5 * half_r1 if tp1_hit else 0.0
        trades.append({"time": df_raw["time"].iloc[i], "side": sig.side, "entry": entry,
                       "bars": j - i, "R": result})
        i = max(j, i + 1)
    t = pd.DataFrame(trades)
    return {"trades": t, "stats": summarise(t)}


def summarise(t: pd.DataFrame) -> dict:
    if t.empty:
        return {"trades": 0}
    eq = t["R"].cumsum()
    dd = (eq.cummax() - eq).max()
    wins, losses = t.loc[t["R"] > 0, "R"], t.loc[t["R"] < 0, "R"]
    return {
        "trades": int(len(t)),
        "win_rate_%": round(100 * len(wins) / len(t), 1),
        "total_R": round(float(t["R"].sum()), 2),
        "avg_R": round(float(t["R"].mean()), 3),
        "profit_factor": round(float(wins.sum() / abs(losses.sum())), 2) if len(losses) else float("inf"),
        "max_drawdown_R": round(float(dd), 2),
    }
