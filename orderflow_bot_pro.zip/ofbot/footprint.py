"""Footprint (bid x ask per price level) with imbalance, stacked imbalance and POC."""
import numpy as np
import pandas as pd


def build_footprint(tk: pd.DataFrame, step: float, tf_min: int) -> pd.DataFrame:
    """Returns columns: bar, level, bid, ask, delta, total."""
    if tk is None or tk.empty:
        return pd.DataFrame(columns=["bar", "level", "bid", "ask", "delta", "total"])
    t = tk[["time", "price", "bid_vol", "ask_vol"]].copy()
    t["bar"] = t["time"].dt.floor(f"{tf_min}min")
    t["level"] = (t["price"] / step).round() * step
    fp = t.groupby(["bar", "level"], as_index=False).agg(bid=("bid_vol", "sum"), ask=("ask_vol", "sum"))
    fp["delta"] = fp["ask"] - fp["bid"]
    fp["total"] = fp["ask"] + fp["bid"]
    return fp


def mark_imbalances(fp: pd.DataFrame, step: float, ratio: float = 3.0) -> pd.DataFrame:
    """Diagonal imbalance: ask@L vs bid@(L-step) (buy), bid@L vs ask@(L+step) (sell)."""
    if fp.empty:
        return fp.assign(buy_imb=False, sell_imb=False)
    out = []
    for bar, g in fp.groupby("bar"):
        g = g.sort_values("level").copy()
        bid = dict(zip(g["level"].round(6), g["bid"]))
        ask = dict(zip(g["level"].round(6), g["ask"]))
        buy, sell = [], []
        for lvl in g["level"].round(6):
            b_below = bid.get(round(lvl - step, 6), 0.0)
            a_above = ask.get(round(lvl + step, 6), 0.0)
            buy.append(ask[lvl] > 0 and ask[lvl] >= ratio * max(b_below, 1e-9) and b_below > 0 or
                       (ask[lvl] > 0 and b_below == 0 and ask[lvl] >= ratio))
            sell.append(bid[lvl] > 0 and bid[lvl] >= ratio * max(a_above, 1e-9) and a_above > 0 or
                        (bid[lvl] > 0 and a_above == 0 and bid[lvl] >= ratio))
        g["buy_imb"], g["sell_imb"] = buy, sell
        out.append(g)
    return pd.concat(out, ignore_index=True)


def stacked_imbalances(fp: pd.DataFrame, min_levels: int = 3) -> pd.DataFrame:
    """Runs of >= min_levels consecutive imbalanced levels in the same direction."""
    rows = []
    if fp.empty or "buy_imb" not in fp:
        return pd.DataFrame(columns=["bar", "side", "low", "high", "levels"])
    for bar, g in fp.groupby("bar"):
        g = g.sort_values("level")
        for side, col in (("BUY", "buy_imb"), ("SELL", "sell_imb")):
            run = []
            for lvl, flag in zip(g["level"], g[col]):
                if flag:
                    run.append(lvl)
                else:
                    if len(run) >= min_levels:
                        rows.append({"bar": bar, "side": side, "low": min(run), "high": max(run), "levels": len(run)})
                    run = []
            if len(run) >= min_levels:
                rows.append({"bar": bar, "side": side, "low": min(run), "high": max(run), "levels": len(run)})
    return pd.DataFrame(rows, columns=["bar", "side", "low", "high", "levels"])


def bar_summary(fp: pd.DataFrame) -> pd.DataFrame:
    """Per-bar POC, delta, total volume."""
    if fp.empty:
        return pd.DataFrame(columns=["bar", "poc", "delta", "total"])
    rows = []
    for bar, g in fp.groupby("bar"):
        rows.append({"bar": bar, "poc": g.loc[g["total"].idxmax(), "level"],
                     "delta": g["delta"].sum(), "total": g["total"].sum()})
    return pd.DataFrame(rows)


def footprint_table(fp: pd.DataFrame, last_bars: int = 6) -> pd.DataFrame:
    """Pivot to a 'bid x ask' text grid for display."""
    if fp.empty:
        return pd.DataFrame()
    bars = sorted(fp["bar"].unique())[-last_bars:]
    f = fp[fp["bar"].isin(bars)].copy()
    f["cell"] = f["bid"].round(0).astype(int).astype(str) + " x " + f["ask"].round(0).astype(int).astype(str)
    tbl = f.pivot(index="level", columns="bar", values="cell").sort_index(ascending=False).fillna("")
    tbl.columns = [c.strftime("%H:%M") for c in tbl.columns]
    return tbl


def last_bar_stacked(stacks: pd.DataFrame, bars_back: int = 2):
    """Direction of most recent stacked imbalance within the last few bars."""
    if stacks.empty:
        return None
    bars = sorted(stacks["bar"].unique())[-bars_back:]
    s = stacks[stacks["bar"].isin(bars)]
    if s.empty:
        return None
    b, a = (s["side"] == "BUY").sum(), (s["side"] == "SELL").sum()
    return "BULL" if b > a else "BEAR" if a > b else None
