"""NEXT LEVEL ORDER FLOW BOT - Streamlit UI.  Run: streamlit run app.py"""
import time
from datetime import datetime

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from plotly.subplots import make_subplots

import footprint as fpm
import indicators as ind
import strategy as strat
from atas_bridge import ATASBridge
from backtest import run_backtest
from config import Settings, TIMEFRAMES
from mt5_connector import MT5Client, MT5Error
from risk_manager import RiskManager
from trader import Trader

st.set_page_config(page_title="Order Flow Bot", layout="wide", page_icon="📈")


# ------------------------------------------------------------ session objects
def ss(key, factory):
    if key not in st.session_state:
        st.session_state[key] = factory()
    return st.session_state[key]


client: MT5Client = ss("client", MT5Client)
atas: ATASBridge = ss("atas", ATASBridge)
history = ss("history", list)     # signal log

# ------------------------------------------------------------------- sidebar
sb = st.sidebar
sb.title("MT5 Login")
login = sb.text_input("Login (account number)")
password = sb.text_input("Password", type="password")
server = sb.text_input("Server")
if sb.button("Connect", use_container_width=True):
    try:
        client.connect(login, password, server)
        sb.success("Connected")
    except MT5Error as e:
        sb.error(str(e))

sb.markdown("---")
sb.subheader("Market")
s = Settings()
s.symbol = sb.text_input("Symbol", s.symbol)
s.timeframe = sb.selectbox("Timeframe", list(TIMEFRAMES), index=list(TIMEFRAMES).index(s.timeframe))
s.candles = sb.slider("Candles", 100, 800, s.candles)
s.tick_minutes = sb.slider("Tick history (min)", 10, 360, s.tick_minutes)
s.footprint_step = sb.number_input("Footprint price step", value=s.footprint_step, step=0.1)
s.imbalance_ratio = sb.number_input("Imbalance ratio", value=s.imbalance_ratio, step=0.5)

sb.subheader("Risk")
s.pip_size = sb.number_input("1 pip = price units", value=s.pip_size, format="%.5f")
s.use_risk_pct = sb.checkbox("Lot by risk %", s.use_risk_pct)
s.risk_pct = sb.number_input("Risk % per trade", value=s.risk_pct, step=0.1)
s.lot = sb.number_input("Fixed lot", value=s.lot, step=0.01, min_value=0.01)
s.sl_pips = sb.number_input("SL (pips)", value=s.sl_pips)
s.tp1_pips = sb.number_input("TP1 (pips)", value=s.tp1_pips)
s.tp2_pips = sb.number_input("TP2 (pips)", value=s.tp2_pips)
s.move_be_after_tp1 = sb.checkbox("Move SL to BE after TP1", s.move_be_after_tp1)

sb.subheader("Filters")
s.min_score = sb.slider("Min confluence score", 3, 10, s.min_score)
s.max_trades_per_day = sb.number_input("Max trades / day", value=s.max_trades_per_day, min_value=1)
s.max_daily_loss_pct = sb.number_input("Max daily loss %", value=s.max_daily_loss_pct, step=0.5)
s.cooldown_minutes = sb.number_input("Cooldown (min)", value=s.cooldown_minutes, min_value=0)
s.max_spread_pips = sb.number_input("Max spread (pips)", value=s.max_spread_pips)

sb.subheader("Execution")
s.auto_trade = sb.checkbox("AUTO TRADE", False)
live = sb.checkbox("Live refresh (every 3s)", False)
use_atas = sb.checkbox("Use ATAS feed", False)
s.atas_port = sb.number_input("ATAS port", value=s.atas_port, step=1)
if use_atas:
    atas.port = int(s.atas_port)
    atas.start()

risk: RiskManager = ss("risk", lambda: RiskManager(s))
risk.s = s
trader: Trader = ss("trader", lambda: Trader(client, s, risk))
trader.s = s

# --------------------------------------------------------------------- header
st.title("📈 ORDER FLOW BOT")
if not client.connected:
    st.info("Sidebar eken MT5 login details dala Connect click karanna.")
    st.stop()

try:
    acc = client.account()
    client.select(s.symbol)
    df_raw = client.rates(s.symbol, s.timeframe, s.candles)
    tk_raw = client.ticks(s.symbol, s.tick_minutes)
except MT5Error as e:
    st.error(str(e))
    st.stop()

h1, h2, h3, h4, h5 = st.columns(5)
h1.metric("Account Name", acc["name"])
h2.metric("Wallet Balance", f"{acc['balance']:,.2f} {acc['currency']}")
h3.metric("Equity", f"{acc['equity']:,.2f}", f"{acc['profit']:+,.2f}")
h4.metric("Login / Server", f"{acc['login']}", acc["server"])
h5.markdown("### " + ("🟢 DEMO" if acc["is_demo"] else "🔴 REAL" if acc["mode"] == "REAL" else acc["mode"]))
if s.auto_trade and not acc["is_demo"]:
    st.warning("AUTO TRADE is ON for a REAL account. Backtest + demo test first.")

# ----------------------------------------------------------------- compute
tk = ind.classify_ticks(tk_raw)
if use_atas and atas.trades:
    atas_tk = atas.trades_df()
    if not atas_tk.empty:
        tk = atas_tk       # true futures order flow replaces MT5 approximation
book = atas.dom_as_book() if (use_atas and atas.dom) else client.book(s.symbol)
dom_bias = strat.dom_bias_from_book(book)
a = strat.analyse(df_raw, tk, s, dom_bias)
t_now = client.tick(s.symbol)
sig = strat.evaluate(a, s, bid=t_now.bid, ask=t_now.ask)
df = a["df"]

if sig.side != "WAIT" and (not history or history[-1]["time"] != df["time"].iloc[-1]):
    history.append({"time": df["time"].iloc[-1], "side": sig.side, "entry": round(sig.entry, 3),
                    "sl": round(sig.sl, 3), "tp1": round(sig.tp1, 3), "tp2": round(sig.tp2, 3),
                    "score": max(sig.buy_score, sig.sell_score)})

if tk.empty:
    st.caption("⚠ Tick data empty: delta uses candle proxy. Check symbol / broker tick history.")

# ----------------------------------------------------------------- auto trade
if s.auto_trade and sig.side != "WAIT":
    pnl = client.today_pnl(s.symbol)
    n_today = client.trades_today(s.magic, s.symbol)
    ok, why = risk.can_trade(acc, pnl, n_today, client.spread_pips(s.symbol, s.pip_size),
                             len(client.positions(s.symbol, s.magic)))
    if ok:
        trader.execute(sig, acc)
    else:
        st.caption(f"Auto-trade blocked: {why}")
if s.auto_trade:
    trader.manage()

# ----------------------------------------------------------------------- tabs
tab_dash, tab_fp, tab_dom, tab_sig, tab_bt, tab_pos = st.tabs(
    ["Dashboard", "Footprint", "DOM / Heatmap", "Signals", "Backtest", "Positions"])

with tab_dash:
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Signal", sig.side, f"buy {sig.buy_score} · sell {sig.sell_score}")
    c2.metric("Trend (structure)", sig.info["trend"])
    c3.metric("CVD divergence", a["div"] or "none")
    c4.metric("RSI / ATR", f"{sig.info['rsi']:.0f}", f"ATR {sig.info['atr']:.2f}")
    if sig.side != "WAIT":
        st.success(f"{sig.side} @ {sig.entry:.2f} | SL {sig.sl:.2f} | TP1 {sig.tp1:.2f} | TP2 {sig.tp2:.2f}")
        st.write("Reasons: " + " · ".join(sig.reasons))

    fig = make_subplots(rows=4, cols=1, shared_xaxes=True, row_heights=[0.55, 0.15, 0.15, 0.15],
                        vertical_spacing=0.02, subplot_titles=("Price / VWAP / zones", "Delta", "CVD", "RSI"))
    fig.add_trace(go.Candlestick(x=df["time"], open=df["open"], high=df["high"], low=df["low"],
                                 close=df["close"], name="Price"), row=1, col=1)
    fig.add_trace(go.Scatter(x=df["time"], y=df["vwap"], name="VWAP", line=dict(color="orange")), row=1, col=1)
    for col in ("vwap_up", "vwap_dn"):
        fig.add_trace(go.Scatter(x=df["time"], y=df[col], line=dict(color="orange", dash="dot", width=1),
                                 showlegend=False), row=1, col=1)
    fig.add_trace(go.Scatter(x=df["time"], y=df["ema50"], name="EMA50", line=dict(color="violet", width=1)), row=1, col=1)
    pr = a["profile"]
    for name, val, colr in (("POC", pr["poc"], "yellow"), ("VAH", pr["vah"], "gray"), ("VAL", pr["val"], "gray")):
        fig.add_hline(y=val, line=dict(color=colr, dash="dash", width=1), annotation_text=name, row=1, col=1)
    for z in a["fvg"][-5:] + a["ob"][-3:]:
        fig.add_hrect(y0=z["low"], y1=z["high"], row=1, col=1, line_width=0,
                      fillcolor="rgba(0,200,0,0.15)" if z["kind"] == "BULL" else "rgba(220,0,0,0.15)")
    fig.add_trace(go.Bar(x=df["time"], y=df["delta"], name="Delta",
                         marker_color=np.where(df["delta"] >= 0, "#26a69a", "#ef5350")), row=2, col=1)
    fig.add_trace(go.Scatter(x=df["time"], y=df["cvd"], name="CVD", line=dict(color="cyan")), row=3, col=1)
    fig.add_trace(go.Scatter(x=df["time"], y=df["rsi"], name="RSI", line=dict(color="white")), row=4, col=1)
    fig.add_hline(y=70, line=dict(dash="dot", color="red"), row=4, col=1)
    fig.add_hline(y=30, line=dict(dash="dot", color="green"), row=4, col=1)
    fig.update_layout(height=850, xaxis_rangeslider_visible=False, template="plotly_dark")
    st.plotly_chart(fig, use_container_width=True)

with tab_fp:
    st.subheader("Footprint (bid x ask)")
    if a["fp"].empty:
        st.write("No tick data available.")
    else:
        n_bars = st.slider("Bars to show", 3, 15, 6)
        st.dataframe(fpm.footprint_table(a["fp"], n_bars), height=520, use_container_width=True)
        st.subheader("Stacked imbalances")
        st.dataframe(a["stacks"].tail(15), use_container_width=True)
        st.subheader("Bar summary (POC / delta)")
        st.dataframe(fpm.bar_summary(a["fp"]).tail(15), use_container_width=True)
        hist = pr["hist"]
        vp = go.Figure(go.Bar(x=hist, y=pr["mids"], orientation="h", marker_color="steelblue"))
        vp.update_layout(height=400, template="plotly_dark", title="Volume profile")
        st.plotly_chart(vp, use_container_width=True)

with tab_dom:
    st.subheader("Depth of market")
    st.write(f"DOM bias: **{dom_bias or 'neutral / unavailable'}**")
    if book:
        b = pd.DataFrame(book).sort_values("price", ascending=False)
        b["side"] = b["type"].map({1: "ASK", 2: "BID"})
        st.dataframe(b[["price", "volume", "side"]], height=300, use_container_width=True)
        snaps = ss("dom_hist", list)
        snaps.append((datetime.now(), {x["price"]: x["volume"] for x in book}))
        del snaps[:-150]
        px_levels = sorted({p for _, snap in snaps for p in snap})
        z = [[snap.get(p, 0) for _, snap in snaps] for p in px_levels]
        hm = go.Figure(go.Heatmap(z=z, x=[t for t, _ in snaps], y=px_levels, colorscale="Hot"))
        hm.update_layout(height=500, template="plotly_dark", title="Liquidity heatmap (needs live refresh)")
        st.plotly_chart(hm, use_container_width=True)
    else:
        st.info("Broker gives no market depth for this symbol. Enable 'Use ATAS feed' for real DOM.")
    st.caption(f"ATAS: running={atas.running} messages={atas.messages} error={atas.error}")

with tab_sig:
    st.subheader("Score breakdown")
    l, r = st.columns(2)
    l.write("**Buy** (" + str(sig.buy_score) + ")"); l.write(sig.reasons_buy or "-")
    r.write("**Sell** (" + str(sig.sell_score) + ")"); r.write(sig.reasons_sell or "-")
    st.subheader("Signal history (this session)")
    st.dataframe(pd.DataFrame(history).tail(50), use_container_width=True)
    st.subheader("Execution log")
    st.code("\n".join(trader.events[-30:]) or "no events")

with tab_bt:
    st.subheader("Backtest (candle-delta proxy)")
    st.caption("Tick order flow is not available for long history, so this tests the structure side "
               "of the strategy. Treat results as indicative, then forward-test on demo.")
    bt_n = st.slider("Bars to test", 300, 5000, 1500, step=100)
    if st.button("Run backtest"):
        with st.spinner("Running..."):
            big = client.rates(s.symbol, s.timeframe, bt_n)
            res = run_backtest(big, s)
        st.json(res["stats"])
        t = res["trades"]
        if not t.empty:
            st.line_chart(t.set_index("time")["R"].cumsum())
            st.dataframe(t, use_container_width=True)

with tab_pos:
    pos = client.positions(s.symbol, s.magic)
    st.subheader(f"Open positions ({len(pos)})")
    if pos:
        st.dataframe(pd.DataFrame([{"ticket": p.ticket, "type": "BUY" if p.type == 0 else "SELL",
                                    "lots": p.volume, "open": p.price_open, "sl": p.sl, "tp": p.tp,
                                    "profit": p.profit, "comment": p.comment} for p in pos]),
                     use_container_width=True)
    if st.button("Close all bot positions"):
        trader.close_all()
        st.rerun()
    st.metric("Today P&L (closed)", f"{client.today_pnl(s.symbol):,.2f}")

if live:
    time.sleep(3)
    st.rerun()
