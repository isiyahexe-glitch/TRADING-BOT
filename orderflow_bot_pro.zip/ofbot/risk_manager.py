"""Position sizing and safety gates."""
from datetime import datetime, timedelta
from config import Settings


class RiskManager:
    def __init__(self, s: Settings):
        self.s = s
        self.last_trade_at = None
        self.log = []

    def lot_size(self, balance: float, symbol_info, tick_value_per_lot_pip: float = None) -> float:
        s = self.s
        if not s.use_risk_pct:
            return self._norm(s.lot, symbol_info)
        # risk money / (SL in price units * value per price unit per lot)
        sl_price = s.sl_pips * s.pip_size
        per_unit = symbol_info.trade_tick_value / symbol_info.trade_tick_size
        lots = (balance * s.risk_pct / 100.0) / (sl_price * per_unit)
        return self._norm(lots, symbol_info)

    @staticmethod
    def _norm(lots: float, info) -> float:
        step = info.volume_step or 0.01
        lots = round(lots / step) * step
        return float(min(max(lots, info.volume_min), info.volume_max))

    def can_trade(self, acc: dict, today_pnl: float, trades_today: int, spread_pips: float, open_positions: int):
        """Return (ok, reason)."""
        s = self.s
        if open_positions > 0:
            return False, "position already open"
        if trades_today >= s.max_trades_per_day:
            return False, f"max trades/day reached ({s.max_trades_per_day})"
        if acc["balance"] > 0 and today_pnl <= -acc["balance"] * s.max_daily_loss_pct / 100.0:
            return False, f"daily loss limit hit ({s.max_daily_loss_pct}%)"
        if spread_pips > s.max_spread_pips:
            return False, f"spread too wide ({spread_pips:.1f} pips)"
        if self.last_trade_at and datetime.utcnow() - self.last_trade_at < timedelta(minutes=s.cooldown_minutes):
            return False, "cooldown active"
        return True, "ok"

    def mark_trade(self):
        self.last_trade_at = datetime.utcnow()
