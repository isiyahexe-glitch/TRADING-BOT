"""Price + order-flow indicators. Pure pandas/numpy, no MT5 dependency."""
import numpy as np
import pandas as pd

TICK_FLAG_BUY = 32
TICK_FLAG_SELL = 64


# ------------------------------------------------------------------ classics
def ema(s: pd.Series, n: int) -> pd.Series:
    return s.ewm(span=n, adjust=False).mean()


def atr(df: pd.DataFrame, n: int = 14) -> pd.Series:
    pc = df["close"].shift()
    tr = pd.concat([df["high"] - df["low"], (df["high"] - pc).abs(), (df["low"] - pc).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / n, adjust=False).mean()


def rsi(s: pd.Series, n: int = 14) -> pd.Series:
    d = s.diff()
    up = d.clip(lower=0).ewm(alpha=1 / n, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1 / n, adjust=False).mean()
    return 100 - 100 / (1 + up / dn.replace(0, np.nan))


# --------------------------------------------------------------------- VWAP
def session_vwap(df: pd.DataFrame, bands: float = 1.0) -> pd.DataFrame:
    """Daily-anchored VWAP with standard-deviation bands (uses tick_volume)."""
    out = df.copy()
    tp = (df["high"] + df["low"] + df["close"]) / 3
    v = df["tick_volume"].replace(0, 1).astype(float)
    day = df["time"].dt.date
    cum_v = v.groupby(day).cumsum()
    cum_pv = (tp * v).groupby(day).cumsum()
    out["vwap"] = cum_pv / cum_v
    cum_p2v = (tp ** 2 * v).groupby(day).cumsum()
    var = (cum_p2v / cum_v - out["vwap"] ** 2).clip(lower=0)
    sd = np.sqrt(var)
    out["vwap_up"] = out["vwap"] + bands * sd
    out["vwap_dn"] = out["vwap"] - bands * sd
    return out


# ------------------------------------------------------------- tick -> delta
def classify_ticks(tk: pd.DataFrame) -> pd.DataFrame:
    """Add price, vol, delta, ask_vol, bid_vol, cvd to a raw tick frame."""
    if tk is None or tk.empty:
        return pd.DataFrame()
    t = tk.copy()
    mid = (t["bid"] + t["ask"]) / 2
    t["price"] = np.where(t["last"] > 0, t["last"], mid)
    if "volume_real" in t and (t["volume_real"] > 0).any():
        vol = t["volume_real"].where(t["volume_real"] > 0, 1.0)
    elif "volume" in t and (t["volume"] > 0).any():
        vol = t["volume"].where(t["volume"] > 0, 1.0)
    else:
        vol = pd.Series(1.0, index=t.index)
    t["vol"] = vol.astype(float)

    flags = t["flags"].fillna(0).astype(int)
    f_buy = (flags & TICK_FLAG_BUY) > 0
    f_sell = (flags & TICK_FLAG_SELL) > 0
    # tick rule fallback (works for forex quotes with no aggressor flag)
    sign = np.sign(t["price"].diff()).replace(0, np.nan).ffill().fillna(0)
    side = np.where(f_buy & ~f_sell, 1, np.where(f_sell & ~f_buy, -1, sign))
    t["delta"] = side * t["vol"]
    t["ask_vol"] = np.where(side > 0, t["vol"], 0.0)
    t["bid_vol"] = np.where(side < 0, t["vol"], 0.0)
    t["cvd"] = t["delta"].cumsum()
    return t


def bar_orderflow(df: pd.DataFrame, tk: pd.DataFrame, tf_min: int) -> pd.DataFrame:
    """Attach per-candle delta / cvd / max & min delta from ticks (or a candle proxy)."""
    out = df.copy()
    if tk is None or tk.empty:
        rng = (df["high"] - df["low"]).replace(0, np.nan)
        out["delta"] = (np.sign(df["close"] - df["open"]) * df["tick_volume"]
                        * ((df["close"] - df["open"]).abs() / rng).fillna(0.2))
        out["delta_proxy"] = True
    else:
        t = tk.copy()
        t["bar"] = t["time"].dt.floor(f"{tf_min}min")
        t["run"] = t.groupby("bar")["delta"].cumsum()
        g = t.groupby("bar")
        out["delta"] = out["time"].map(g["delta"].sum()).fillna(0.0)
        out["delta_max"] = out["time"].map(g["run"].max()).fillna(0.0)
        out["delta_min"] = out["time"].map(g["run"].min()).fillna(0.0)
        out["delta_proxy"] = False
    out["cvd"] = out["delta"].cumsum()
    return out


# ----------------------------------------------------------- market structure
def swing_points(df: pd.DataFrame, n: int = 3):
    hi = df["high"].where(df["high"] == df["high"].rolling(2 * n + 1, center=True).max())
    lo = df["low"].where(df["low"] == df["low"].rolling(2 * n + 1, center=True).min())
    return hi.dropna(), lo.dropna()


def market_structure(df: pd.DataFrame, n: int = 3) -> dict:
    """Trend from last two swing highs/lows plus BOS / CHoCH on the latest close."""
    hi, lo = swing_points(df.iloc[:-n] if len(df) > 3 * n else df, n)
    res = {"trend": "RANGE", "bos": None, "choch": None, "last_high": None, "last_low": None}
    if len(hi) < 2 or len(lo) < 2:
        return res
    hh = hi.iloc[-1] > hi.iloc[-2]
    hl = lo.iloc[-1] > lo.iloc[-2]
    lh = hi.iloc[-1] < hi.iloc[-2]
    ll = lo.iloc[-1] < lo.iloc[-2]
    res["trend"] = "UP" if hh and hl else "DOWN" if lh and ll else "RANGE"
    res["last_high"], res["last_low"] = float(hi.iloc[-1]), float(lo.iloc[-1])
    c = df["close"].iloc[-1]
    if c > res["last_high"]:
        res["bos" if res["trend"] == "UP" else "choch"] = "BULL"
    elif c < res["last_low"]:
        res["bos" if res["trend"] == "DOWN" else "choch"] = "BEAR"
    return res


# ------------------------------------------------------------ ICT-style zones
def fair_value_gaps(df: pd.DataFrame, lookback: int = 60) -> list:
    """3-candle imbalance zones that price has not fully filled yet."""
    gaps = []
    d = df.tail(lookback).reset_index(drop=True)
    for i in range(2, len(d)):
        if d["low"][i] > d["high"][i - 2]:
            lo, hi, kind = d["high"][i - 2], d["low"][i], "BULL"
        elif d["high"][i] < d["low"][i - 2]:
            lo, hi, kind = d["high"][i], d["low"][i - 2], "BEAR"
        else:
            continue
        later = d.iloc[i + 1:]
        filled = (kind == "BULL" and len(later) and later["low"].min() <= lo) or \
                 (kind == "BEAR" and len(later) and later["high"].max() >= hi)
        if not filled:
            gaps.append({"kind": kind, "low": float(lo), "high": float(hi), "time": d["time"][i]})
    return gaps


def order_blocks(df: pd.DataFrame, lookback: int = 60, atr_mult: float = 1.2) -> list:
    """Last opposite candle before an impulsive move (body > atr_mult * ATR)."""
    d = df.tail(lookback + 15).reset_index(drop=True)
    a = atr(d)
    blocks = []
    for i in range(1, len(d)):
        body = d["close"][i] - d["open"][i]
        if abs(body) < atr_mult * a[i - 1]:
            continue
        prev_bull = d["close"][i - 1] > d["open"][i - 1]
        if body > 0 and not prev_bull:
            blocks.append({"kind": "BULL", "low": float(d["low"][i - 1]),
                           "high": float(d["high"][i - 1]), "time": d["time"][i - 1]})
        elif body < 0 and prev_bull:
            blocks.append({"kind": "BEAR", "low": float(d["low"][i - 1]),
                           "high": float(d["high"][i - 1]), "time": d["time"][i - 1]})
    return blocks[-6:]


def in_zone(price: float, zones: list, kind: str) -> bool:
    return any(z["kind"] == kind and z["low"] <= price <= z["high"] for z in zones)


def liquidity_sweep(df: pd.DataFrame, n: int = 3, window: int = 3) -> str:
    """Stop-hunt: wick through a prior swing then close back inside."""
    hi, lo = swing_points(df.iloc[:-window], n)
    if len(hi) == 0 or len(lo) == 0:
        return None
    last = df.tail(window)
    sh, sl = hi.iloc[-1], lo.iloc[-1]
    if (last["high"].max() > sh) and (last["close"].iloc[-1] < sh):
        return "BEAR"
    if (last["low"].min() < sl) and (last["close"].iloc[-1] > sl):
        return "BULL"
    return None


# ------------------------------------------------------------ volume profile
def volume_profile(df: pd.DataFrame, tk: pd.DataFrame = None, bins: int = 40, va: float = 0.7) -> dict:
    """POC / value area high & low from ticks if present, else candle volume."""
    if tk is not None and not tk.empty:
        px, vv = tk["price"].values, tk["vol"].values
    else:
        px, vv = ((df["high"] + df["low"] + df["close"]) / 3).values, df["tick_volume"].values.astype(float)
    hist, edges = np.histogram(px, bins=bins, weights=vv)
    mids = (edges[:-1] + edges[1:]) / 2
    poc_i = int(hist.argmax())
    total, acc, lo_i, hi_i = hist.sum(), hist[poc_i], poc_i, poc_i
    while acc < va * total and (lo_i > 0 or hi_i < len(hist) - 1):
        up = hist[hi_i + 1] if hi_i < len(hist) - 1 else -1
        dn = hist[lo_i - 1] if lo_i > 0 else -1
        if up >= dn:
            hi_i += 1; acc += hist[hi_i]
        else:
            lo_i -= 1; acc += hist[lo_i]
    return {"poc": float(mids[poc_i]), "vah": float(mids[hi_i]), "val": float(mids[lo_i]),
            "hist": hist, "mids": mids}


# --------------------------------------------------------- order-flow signals
def cvd_divergence(df: pd.DataFrame, look: int = 14):
    """BEAR: price makes high but CVD does not. BULL: price low but CVD does not."""
    w = df.tail(look)
    if len(w) < look:
        return None
    price_hh = w["high"].iloc[-1] >= w["high"].max() or w["close"].iloc[-1] >= w["close"].max()
    price_ll = w["low"].iloc[-1] <= w["low"].min() or w["close"].iloc[-1] <= w["close"].min()
    cvd_hh = w["cvd"].iloc[-1] >= w["cvd"].max()
    cvd_ll = w["cvd"].iloc[-1] <= w["cvd"].min()
    if price_hh and not cvd_hh:
        return "BEAR"
    if price_ll and not cvd_ll:
        return "BULL"
    return None


def absorption(df: pd.DataFrame, look: int = 3) -> str:
    """Heavy one-sided delta with little price progress = passive absorption."""
    w = df.tail(look)
    a = atr(df).iloc[-1]
    if np.isnan(a) or a == 0:
        return None
    move = w["close"].iloc[-1] - w["open"].iloc[0]
    d = w["delta"].sum()
    thr = df["delta"].abs().tail(50).mean() * look * 0.8
    if d > thr and move < 0.3 * a:
        return "BEAR"   # buyers absorbed by sellers
    if d < -thr and move > -0.3 * a:
        return "BULL"
    return None
