"""Order execution (TP1 / TP2 split) and position management (break-even)."""
from config import Settings
from mt5_connector import MT5Client
from risk_manager import RiskManager
from strategy import Signal

try:
    import MetaTrader5 as mt5
except ImportError:
    mt5 = None


class Trader:
    def __init__(self, client: MT5Client, s: Settings, risk: RiskManager):
        self.c, self.s, self.risk = client, s, risk
        self.events = []

    def _log(self, msg: str):
        self.events.append(msg)
        self.events = self.events[-200:]

    def execute(self, sig: Signal, acc: dict) -> bool:
        s = self.s
        info = self.c.symbol_info(s.symbol)
        total = self.risk.lot_size(acc["balance"], info)
        half = self.risk._norm(total / 2, info)
        if total < 2 * info.volume_min:       # cannot split: send one order to TP2
            r = self.c.send_market(s.symbol, sig.side, total, sig.sl, sig.tp2, s.magic, "OF-TP2")
            ok = r is not None and r.retcode == mt5.TRADE_RETCODE_DONE
            self._log(f"{sig.side} {total} single -> {getattr(r, 'retcode', None)}")
        else:
            r1 = self.c.send_market(s.symbol, sig.side, half, sig.sl, sig.tp1, s.magic, "OF-TP1")
            r2 = self.c.send_market(s.symbol, sig.side, half, sig.sl, sig.tp2, s.magic, "OF-TP2")
            ok = all(r is not None and r.retcode == mt5.TRADE_RETCODE_DONE for r in (r1, r2))
            self._log(f"{sig.side} {half}x2 -> {getattr(r1, 'retcode', None)}/{getattr(r2, 'retcode', None)}")
        if ok:
            self.risk.mark_trade()
        return ok

    def manage(self):
        """After TP1 closes, move the TP2 position's SL to break-even."""
        if not self.s.move_be_after_tp1:
            return
        pos = self.c.positions(self.s.symbol, self.s.magic)
        tp1 = [p for p in pos if p.comment == "OF-TP1"]
        tp2 = [p for p in pos if p.comment == "OF-TP2"]
        if tp1 or not tp2:
            return
        for p in tp2:
            buy = p.type == mt5.POSITION_TYPE_BUY
            be = p.price_open
            needs = (p.sl < be) if buy else (p.sl > be or p.sl == 0)
            if needs:
                r = self.c.modify_sl(p, be)
                self._log(f"BE set on #{p.ticket} -> {getattr(r, 'retcode', None)}")

    def close_all(self):
        for p in self.c.positions(self.s.symbol, self.s.magic):
            r = self.c.close_position(p)
            self._log(f"closed #{p.ticket} -> {getattr(r, 'retcode', None)}")
