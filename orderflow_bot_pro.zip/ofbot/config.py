"""Central settings for the Order Flow bot."""
from dataclasses import dataclass, asdict

TIMEFRAMES = {"M1": 1, "M5": 5, "M15": 15, "M30": 30, "H1": 60, "H4": 240}


@dataclass
class Settings:
    # market
    symbol: str = "XAUUSD"
    timeframe: str = "M5"
    candles: int = 300
    tick_minutes: int = 90
    # footprint
    footprint_step: float = 0.5
    imbalance_ratio: float = 3.0
    stacked_levels: int = 3
    # risk
    pip_size: float = 0.1            # gold 0.1, 5-digit FX 0.0001, JPY 0.01
    lot: float = 0.01
    use_risk_pct: bool = False
    risk_pct: float = 0.5
    sl_pips: float = 20.0
    tp1_pips: float = 100.0
    tp2_pips: float = 200.0
    move_be_after_tp1: bool = True
    # filters
    min_score: int = 5
    min_lead: int = 2
    max_trades_per_day: int = 5
    max_daily_loss_pct: float = 3.0
    cooldown_minutes: int = 30
    max_spread_pips: float = 5.0
    # execution
    magic: int = 777001
    auto_trade: bool = False
    # atas
    atas_port: int = 9099

    def tf_minutes(self) -> int:
        return TIMEFRAMES[self.timeframe]

    def to_dict(self) -> dict:
        return asdict(self)
