"""TCP receiver for ATAS. ATAS has no Python API: run a small C# indicator inside ATAS
that sends one JSON object per line to 127.0.0.1:<port>, e.g.
  {"t": "trade", "time": 1718000000.1, "price": 2350.5, "vol": 3, "side": "buy"}
  {"t": "dom",   "time": 1718000000.1, "bids": [[2350.4, 120], ...], "asks": [[2350.6, 80], ...]}
"""
import json
import socket
import threading
from collections import deque

import pandas as pd


class ATASBridge:
    def __init__(self, port: int = 9099, maxlen: int = 200000):
        self.port = port
        self.trades = deque(maxlen=maxlen)
        self.dom = None
        self.dom_hist = deque(maxlen=300)
        self.messages = 0
        self.running = False
        self.error = None

    def start(self):
        if self.running:
            return
        self.running = True
        threading.Thread(target=self._serve, daemon=True).start()

    def _serve(self):
        srv = socket.socket()
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            srv.bind(("127.0.0.1", self.port))
            srv.listen(1)
        except OSError as e:
            self.error = str(e)
            self.running = False
            return
        while True:
            conn, _ = srv.accept()
            threading.Thread(target=self._client, args=(conn,), daemon=True).start()

    def _client(self, conn):
        for line in conn.makefile():
            try:
                m = json.loads(line)
            except ValueError:
                continue
            self.messages += 1
            if m.get("t") == "trade":
                self.trades.append(m)
            elif m.get("t") == "dom":
                self.dom = m
                self.dom_hist.append(m)

    # ------------------------------------------------------------------ views
    def trades_df(self) -> pd.DataFrame:
        """Tick-like frame in the same shape indicators.classify_ticks produces."""
        if not self.trades:
            return pd.DataFrame()
        d = pd.DataFrame(list(self.trades))
        d["time"] = pd.to_datetime(d["time"], unit="s")
        d["vol"] = d["vol"].astype(float)
        sign = d["side"].map({"buy": 1, "sell": -1}).fillna(0)
        d["delta"] = sign * d["vol"]
        d["ask_vol"] = d["vol"].where(sign > 0, 0.0)
        d["bid_vol"] = d["vol"].where(sign < 0, 0.0)
        d["cvd"] = d["delta"].cumsum()
        return d[["time", "price", "vol", "delta", "ask_vol", "bid_vol", "cvd"]]

    def dom_as_book(self):
        """Convert latest DOM message to the MT5-style book list (type 1 = ask, 2 = bid)."""
        if not self.dom:
            return None
        out = [{"price": p, "volume": v, "type": 2} for p, v in self.dom.get("bids", [])]
        out += [{"price": p, "volume": v, "type": 1} for p, v in self.dom.get("asks", [])]
        return out

    def heatmap_frame(self) -> pd.DataFrame:
        rows = []
        for m in self.dom_hist:
            for p, v in m.get("bids", []) + m.get("asks", []):
                rows.append({"time": pd.to_datetime(m["time"], unit="s"), "price": p, "volume": v})
        return pd.DataFrame(rows)
