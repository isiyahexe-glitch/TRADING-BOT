"""Thin wrapper around the MetaTrader5 python package (Windows only)."""
from datetime import datetime, timedelta
import pandas as pd

try:
    import MetaTrader5 as mt5
except ImportError:  # allows importing on Linux/mac for testing
    mt5 = None


class MT5Error(Exception):
    pass


class MT5Client:
    def __init__(self):
        self.connected = False

    # ------------------------------------------------------------ connection
    def connect(self, login: str = "", password: str = "", server: str = "") -> None:
        if mt5 is None:
            raise MT5Error("MetaTrader5 package not available (Windows + MT5 terminal required)")
        if login:
            ok = mt5.initialize(login=int(login), password=password, server=server)
        else:
            ok = mt5.initialize()
        if not ok:
            raise MT5Error(f"initialize failed: {mt5.last_error()}")
        self.connected = True

    def shutdown(self) -> None:
        if mt5 is not None and self.connected:
            mt5.shutdown()
        self.connected = False

    # --------------------------------------------------------------- account
    def account(self) -> dict:
        a = mt5.account_info()
        if a is None:
            raise MT5Error("account_info() returned None")
        return {
            "name": a.name, "login": a.login, "server": a.server,
            "balance": a.balance, "equity": a.equity, "margin_free": a.margin_free,
            "profit": a.profit, "currency": a.currency, "leverage": a.leverage,
            "is_demo": a.trade_mode == mt5.ACCOUNT_TRADE_MODE_DEMO,
            "mode": {mt5.ACCOUNT_TRADE_MODE_DEMO: "DEMO",
                     mt5.ACCOUNT_TRADE_MODE_CONTEST: "CONTEST",
                     mt5.ACCOUNT_TRADE_MODE_REAL: "REAL"}.get(a.trade_mode, "UNKNOWN"),
        }

    # ---------------------------------------------------------------- market
    def select(self, symbol: str) -> None:
        if not mt5.symbol_select(symbol, True):
            raise MT5Error(f"cannot select {symbol}")

    def server_now(self, symbol: str) -> datetime:
        t = mt5.symbol_info_tick(symbol)
        if t is None:
            raise MT5Error("no tick")
        return datetime.utcfromtimestamp(t.time)

    def spread_pips(self, symbol: str, pip_size: float) -> float:
        t = mt5.symbol_info_tick(symbol)
        return (t.ask - t.bid) / pip_size if t else 999.0

    def rates(self, symbol: str, tf: str, n: int) -> pd.DataFrame:
        r = mt5.copy_rates_from_pos(symbol, getattr(mt5, "TIMEFRAME_" + tf), 0, n)
        if r is None or len(r) == 0:
            raise MT5Error(f"no rates for {symbol}")
        df = pd.DataFrame(r)
        df["time"] = pd.to_datetime(df["time"], unit="s")
        return df

    def ticks(self, symbol: str, minutes: int) -> pd.DataFrame:
        end = self.server_now(symbol)
        raw = mt5.copy_ticks_from(symbol, end - timedelta(minutes=minutes), 400000, mt5.COPY_TICKS_ALL)
        if raw is None or len(raw) == 0:
            return pd.DataFrame()
        tk = pd.DataFrame(raw)
        tk["time"] = pd.to_datetime(tk["time_msc"], unit="ms")
        return tk

    def book(self, symbol: str):
        """Market depth snapshot -> {price: volume} or None if broker gives no DOM."""
        if not mt5.market_book_add(symbol):
            return None
        b = mt5.market_book_get(symbol)
        if not b:
            return None
        return [{"price": x.price, "volume": x.volume_dbl or x.volume, "type": x.type} for x in b]

    def tick(self, symbol: str):
        return mt5.symbol_info_tick(symbol)

    def symbol_info(self, symbol: str):
        return mt5.symbol_info(symbol)

    # ------------------------------------------------------------- positions
    def positions(self, symbol: str = None, magic: int = None) -> list:
        p = mt5.positions_get(symbol=symbol) if symbol else mt5.positions_get()
        p = list(p) if p else []
        if magic is not None:
            p = [x for x in p if x.magic == magic]
        return p

    def today_pnl(self, symbol: str) -> float:
        end = self.server_now(symbol) + timedelta(hours=1)
        start = end.replace(hour=0, minute=0, second=0, microsecond=0) - timedelta(hours=3)
        deals = mt5.history_deals_get(start, end)
        if not deals:
            return 0.0
        day0 = end.replace(hour=0, minute=0, second=0, microsecond=0).timestamp()
        return sum(d.profit + d.commission + d.swap for d in deals
                   if d.entry == mt5.DEAL_ENTRY_OUT and d.time >= day0)

    def trades_today(self, magic: int, symbol: str) -> int:
        end = self.server_now(symbol) + timedelta(hours=1)
        start = end.replace(hour=0, minute=0, second=0, microsecond=0)
        deals = mt5.history_deals_get(start, end)
        if not deals:
            return 0
        return len([d for d in deals if d.magic == magic and d.entry == mt5.DEAL_ENTRY_IN]) // 2

    # ---------------------------------------------------------------- orders
    def _filling(self, symbol: str):
        mode = mt5.symbol_info(symbol).filling_mode
        if mode & 2:
            return mt5.ORDER_FILLING_IOC
        if mode & 1:
            return mt5.ORDER_FILLING_FOK
        return mt5.ORDER_FILLING_RETURN

    def send_market(self, symbol, side, volume, sl, tp, magic, comment):
        t = mt5.symbol_info_tick(symbol)
        buy = side == "BUY"
        req = {
            "action": mt5.TRADE_ACTION_DEAL, "symbol": symbol, "volume": volume,
            "type": mt5.ORDER_TYPE_BUY if buy else mt5.ORDER_TYPE_SELL,
            "price": t.ask if buy else t.bid, "sl": sl, "tp": tp, "deviation": 20,
            "magic": magic, "comment": comment, "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": self._filling(symbol),
        }
        return mt5.order_send(req)

    def modify_sl(self, position, new_sl: float):
        req = {"action": mt5.TRADE_ACTION_SLTP, "position": position.ticket,
               "symbol": position.symbol, "sl": new_sl, "tp": position.tp}
        return mt5.order_send(req)

    def close_position(self, position):
        t = mt5.symbol_info_tick(position.symbol)
        buy = position.type == mt5.POSITION_TYPE_BUY
        req = {
            "action": mt5.TRADE_ACTION_DEAL, "symbol": position.symbol,
            "volume": position.volume, "position": position.ticket,
            "type": mt5.ORDER_TYPE_SELL if buy else mt5.ORDER_TYPE_BUY,
            "price": t.bid if buy else t.ask, "deviation": 20, "magic": position.magic,
            "comment": "OF close", "type_time": mt5.ORDER_TIME_GTC,
            "type_filling": self._filling(position.symbol),
        }
        return mt5.order_send(req)
