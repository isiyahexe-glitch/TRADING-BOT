"""Confluence strategy: VWAP + CVD + footprint + DOM/ATAS + price action + ICT zones."""
from dataclasses import dataclass, field
import numpy as np
import pandas as pd

import indicators as ind
import footprint as fpm
from config import Settings


@dataclass
class Signal:
    side: str = "WAIT"            # BUY / SELL / WAIT
    buy_score: int = 0
    sell_score: int = 0
    entry: float = 0.0
    sl: float = 0.0
    tp1: float = 0.0
    tp2: float = 0.0
    reasons_buy: list = field(default_factory=list)
    reasons_sell: list = field(default_factory=list)
    info: dict = field(default_factory=dict)

    @property
    def reasons(self):
        return self.reasons_buy if self.side == "BUY" else self.reasons_sell


def _add(cond, side, text, buy, sell):
    if not cond:
        return
    (buy if side == "BULL" else sell).append(text)


def analyse(df_raw: pd.DataFrame, tk: pd.DataFrame, s: Settings, dom_bias: str = None) -> dict:
    """Compute every indicator once and return a dict used by both strategy and UI."""
    df = ind.session_vwap(df_raw)
    df = ind.bar_orderflow(df, tk, s.tf_minutes())
    df["ema20"], df["ema50"] = ind.ema(df["close"], 20), ind.ema(df["close"], 50)
    df["rsi"], df["atr"] = ind.rsi(df["close"]), ind.atr(df)
    fp = pd.DataFrame()
    stacks = pd.DataFrame()
    if tk is not None and not tk.empty:
        fp = fpm.build_footprint(tk, s.footprint_step, s.tf_minutes())
        fp = fpm.mark_imbalances(fp, s.footprint_step, s.imbalance_ratio)
        stacks = fpm.stacked_imbalances(fp, s.stacked_levels)
    return {
        "df": df, "fp": fp, "stacks": stacks,
        "structure": ind.market_structure(df),
        "fvg": ind.fair_value_gaps(df), "ob": ind.order_blocks(df),
        "sweep": ind.liquidity_sweep(df), "div": ind.cvd_divergence(df),
        "absorb": ind.absorption(df), "profile": ind.volume_profile(df, tk),
        "dom_bias": dom_bias,
    }


def evaluate(a: dict, s: Settings, bid: float = None, ask: float = None) -> Signal:
    df = a["df"]
    last = df.iloc[-1]
    px = float(last["close"])
    buy, sell = [], []

    # 1. trend (EMA stack)
    _add(last["ema20"] > last["ema50"] and px > last["ema50"], "BULL", "EMA trend up", buy, sell)
    _add(last["ema20"] < last["ema50"] and px < last["ema50"], "BEAR", "EMA trend down", buy, sell)
    # 2. VWAP side
    _add(px > last["vwap"], "BULL", "Above VWAP", buy, sell)
    _add(px < last["vwap"], "BEAR", "Below VWAP", buy, sell)
    # 3. delta of last 3 bars
    d3 = df["delta"].tail(3).sum()
    _add(d3 > 0, "BULL", "Positive delta (3 bars)", buy, sell)
    _add(d3 < 0, "BEAR", "Negative delta (3 bars)", buy, sell)
    # 4. CVD slope
    slope = df["cvd"].iloc[-1] - df["cvd"].iloc[-6]
    _add(slope > 0, "BULL", "CVD rising", buy, sell)
    _add(slope < 0, "BEAR", "CVD falling", buy, sell)
    # 5. CVD divergence (worth 2: reversal edge)
    if a["div"]:
        for _ in range(2):
            _add(True, a["div"], f"CVD divergence ({a['div']})", buy, sell)
    # 6. structure
    st_ = a["structure"]
    _add(st_["bos"] == "BULL" or st_["choch"] == "BULL", "BULL", "BOS/CHoCH up", buy, sell)
    _add(st_["bos"] == "BEAR" or st_["choch"] == "BEAR", "BEAR", "BOS/CHoCH down", buy, sell)
    # 7. ICT zones retest
    _add(ind.in_zone(px, a["fvg"], "BULL") or ind.in_zone(px, a["ob"], "BULL"), "BULL", "In bull FVG/OB", buy, sell)
    _add(ind.in_zone(px, a["fvg"], "BEAR") or ind.in_zone(px, a["ob"], "BEAR"), "BEAR", "In bear FVG/OB", buy, sell)
    # 8. liquidity sweep
    _add(a["sweep"] == "BULL", "BULL", "Sell-side liquidity swept", buy, sell)
    _add(a["sweep"] == "BEAR", "BEAR", "Buy-side liquidity swept", buy, sell)
    # 9. footprint stacked imbalance
    stk = fpm.last_bar_stacked(a["stacks"])
    _add(stk == "BULL", "BULL", "Stacked buy imbalance", buy, sell)
    _add(stk == "BEAR", "BEAR", "Stacked sell imbalance", buy, sell)
    # 10. absorption
    _add(a["absorb"] == "BULL", "BULL", "Sell absorption", buy, sell)
    _add(a["absorb"] == "BEAR", "BEAR", "Buy absorption", buy, sell)
    # 11. value area
    pr = a["profile"]
    _add(px > pr["poc"] and px < pr["vah"], "BULL", "Above POC", buy, sell)
    _add(px < pr["poc"] and px > pr["val"], "BEAR", "Below POC", buy, sell)
    # 12. DOM / ATAS bias
    _add(a["dom_bias"] == "BULL", "BULL", "DOM bid-heavy", buy, sell)
    _add(a["dom_bias"] == "BEAR", "BEAR", "DOM ask-heavy", buy, sell)
    # 13. RSI room
    _add(last["rsi"] < 70, "BULL", "RSI not overbought", buy, sell)
    _add(last["rsi"] > 30, "BEAR", "RSI not oversold", buy, sell)

    sig = Signal(buy_score=len(buy), sell_score=len(sell), reasons_buy=buy, reasons_sell=sell)
    if sig.buy_score >= s.min_score and sig.buy_score - sig.sell_score >= s.min_lead:
        sig.side = "BUY"
    elif sig.sell_score >= s.min_score and sig.sell_score - sig.buy_score >= s.min_lead:
        sig.side = "SELL"
    if sig.side != "WAIT":
        sg = 1 if sig.side == "BUY" else -1
        sig.entry = (ask if sig.side == "BUY" else bid) or px
        sig.sl = sig.entry - sg * s.sl_pips * s.pip_size
        sig.tp1 = sig.entry + sg * s.tp1_pips * s.pip_size
        sig.tp2 = sig.entry + sg * s.tp2_pips * s.pip_size
    sig.info = {"trend": st_["trend"], "rsi": float(last["rsi"]), "atr": float(last["atr"]),
                "poc": pr["poc"], "vah": pr["vah"], "val": pr["val"]}
    return sig


def dom_bias_from_book(book: list, depth: int = 5):
    """Compare bid vs ask volume of the nearest levels. book items: price/volume/type."""
    if not book:
        return None
    bids = sorted([b for b in book if b["type"] == 2], key=lambda x: -x["price"])[:depth]
    asks = sorted([b for b in book if b["type"] == 1], key=lambda x: x["price"])[:depth]
    bv, av = sum(b["volume"] for b in bids), sum(a["volume"] for a in asks)
    if bv + av == 0:
        return None
    r = bv / (bv + av)
    return "BULL" if r > 0.6 else "BEAR" if r < 0.4 else None
